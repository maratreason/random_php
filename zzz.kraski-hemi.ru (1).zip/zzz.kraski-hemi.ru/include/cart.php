<?php

//var_dump($_POST);

//$db = new DATABASE('cart');

// $b->set($_POST['id']);